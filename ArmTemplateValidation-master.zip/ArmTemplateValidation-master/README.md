# Introduction

Module for validating ARM templates.

This module will also contain a Azure Pipelines task to run this validation as Pester tests against one or more ARM templates.
