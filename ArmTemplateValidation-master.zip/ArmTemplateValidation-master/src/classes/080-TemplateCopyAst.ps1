class TemplateCopyAst : TemplateRootAst {
    [PSObject]$count

    [CopyMode]$mode

    [PSObject]$batchSize
}
