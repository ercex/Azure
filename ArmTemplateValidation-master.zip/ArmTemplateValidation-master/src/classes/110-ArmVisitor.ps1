class ArmVisitor {
    [PSObject] VisitString ([ArmStringValue]$StringValue) {
        return $this
    }
}
