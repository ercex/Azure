enum CopyMode {
    parallel
    serial
}
