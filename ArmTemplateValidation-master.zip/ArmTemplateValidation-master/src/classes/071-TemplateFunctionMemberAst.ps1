class TemplateFunctionMemberAst : TemplateRootAst {
    [string]$UniqueName
    
    [TemplateParameterAst[]]$Parameters

    [TemplateOutputAst[]]$Output
}
